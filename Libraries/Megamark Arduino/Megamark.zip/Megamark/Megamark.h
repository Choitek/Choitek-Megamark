#include <Arduino.h>
#include <Servo.h>

// --- MOTOR CONTROLLER --- //
class MotorController {
  public:
    MotorController(int dir1 = 5, int pwm1 = 4, int dir2 = 3, int pwm2 = 2, 
	                bool invert1 = true, bool invert2 = false);
    void setVelocities(int velocity1, int velocity2);
    void update(int delay = 15);
    void initialize();
  private:
    int DIR1;
    int PWM1;
    int DIR2;
    int PWM2;
    int v1;
    int toV1;
    int v2;
    int toV2;
	bool INV1;
	bool INV2;
    unsigned long endTime;
};

// --- STEPPER MOTOR --- //
class StepperMotor {
  public:
    StepperMotor(int stepPin, int dirPin, int limitPin, int max, bool invertDir = false);
    void stepTo(int steps, bool ignoreHome = false);
    void step(int steps, bool ignoreHome = false);
    void initialize();
    void home();
    int getPos();  
    void update(int delay = 1);
  private:
    int STEP;
    int DIR;
    int LIMIT; 
    unsigned long endTime;    
    bool stepHigh;
    void zero();
    bool invert;
    bool homed;    
    int maxPos;
    int toPos;
    int pos;    
};

// --- SERVO MOTOR --- //
class ServoMotor {
  public:
    ServoMotor(int pin, bool invertDir = false);
    void rotateTo(int angle, bool OnOff = false);
    void rotate(int angle);
    void on(); void off(); 
    bool isAttached();
    void update(float delay = 5.0);
    int getPos();
  private:
    Servo SERVO;
    int PIN;    
    unsigned long endTime;
    float delayTime;   
    bool attached;
    bool invert;
    int toPos;
    int pos;
};

// --- LASER RANGEFINDER --- //
class Laser {
  public:
    Laser(int pin);
	  void initialize();
	  int range(int mode = 2);
  private:
    int PIN;
};

// --- VOLTMETER --- //
class Voltmeter {
  public:
    Voltmeter(int pin = A0, int led = 13);
    int voltage(int mode = 1);
    void initialize();
	  void update();
  private:
    int PIN;
  	int LED;
};

// --- SERIAL HANDLER --- //
class SerialHandler {
  public:
    SerialHandler(int inCnt, int outCnt);
    void initialize(int mode = 0);
    void read();
    void write();
    void setData(int i, int val);
    int getData(int i);
  private:
    char chr;
    int index;
    int inNum;
    String inStr;
    int inData[32];	
    int outNum;
    String outStr;
    int outData[32];
};