#include "Megamark.h"

// --- MOTOR CONTROLLER --- //
MotorController::MotorController(int dir1, int pwm1, int dir2, int pwm2, bool invert1, bool invert2) {
  //assign pins
  DIR1 = dir1; 
  PWM1 = pwm1;
  DIR2 = dir2;
  PWM2 = pwm2;
  INV1 = invert1;
  INV2 = invert2;
  //set initial velocities
  v1 = 0; toV1 = 0;
  v2 = 0; toV2 = 0;
  //set update time
  endTime = 0;
}
void MotorController::initialize() {
  pinMode(DIR1,OUTPUT);
  pinMode(PWM1,OUTPUT);
  pinMode(DIR2,OUTPUT);
  pinMode(PWM2,OUTPUT);
}
void MotorController::setVelocities(int velocity1, int velocity2) { 
  //set velocities
  toV1 = velocity1;
  toV2 = velocity2;  
  //clamp velocities
  if(toV1 > 255)  { toV1 = 255;  }
  if(toV1 < -255) { toV1 = -255; }
  if(toV2 > 255)  { toV2 = 255;  }
  if(toV2 < -255) { toV2 = -255; }
}
void MotorController::update(float delay) {
  unsigned long t = millis();
  if(t > endTime) {
    //increment the time
    endTime = t + delay;
    //accelerate velocity 1
    if(v1 < toV1) { v1 += 1; } 
    if(v1 > toV1) { v1 -= 1; }
    //accelerate velocity 2
    if(v2 < toV2) { v2 += 1; } 
    if(v2 > toV2) { v2 -= 1; }
    //control motor 1 
	if (INV1) {
		if(v1 > 0) { digitalWrite(DIR1,LOW); } 
		else { digitalWrite(DIR1,HIGH); }
	} else {
		if(v1 > 0) { digitalWrite(DIR1,HIGH); } 
		else { digitalWrite(DIR1,LOW); }
	}
    analogWrite(PWM1,abs(v1));      
    //control motor 2 
    if (INV2) {
		if(v2 > 0) { digitalWrite(DIR2,LOW); } 
		else { digitalWrite(DIR2,HIGH); }	
	} else {
		if(v2 > 0) { digitalWrite(DIR2,HIGH); } 
		else { digitalWrite(DIR2,LOW); }
	}
    analogWrite(PWM2,abs(v2));
  }
}

// --- SERVO MOTOR --- //
ServoMotor::ServoMotor(int pin, bool invertDir) {
  PIN = pin;
  invert = invertDir;
  attached = false;
}
void ServoMotor::on() {
  SERVO.attach(PIN);
  attached = true;
  endTime = 0;
  toPos = 90;
  pos = 90; 
}
void ServoMotor::off() {
  SERVO.detach();
  attached = false;
}
void ServoMotor::rotateTo(int angle, bool OnOff) {
  //if On/Off enabled, turn servo off if negative value
  if(OnOff) {
    if (angle < 0) { off(); }
    else if (!attached) { on(); }
  }
  //move only if attached
  if(attached) {
    //set goal position and clamp
    toPos = angle;
    if(toPos < 0)   { toPos = 0;   } 
    if(toPos > 180) { toPos = 180; }
  }
}
void ServoMotor::rotate(int angle) {
  //move only if attached
  if(attached) {
    //set goal position and clamp
    toPos += angle;
    if(toPos < 0)   { toPos = 0;   } 
    if(toPos > 180) { toPos = 180; }
  }
}
void ServoMotor::update(float delay) {
  //move only if attached
  if(attached) {
    unsigned long t = millis();
    if(t > endTime) {
      //increment the time
      endTime = t + delay;
      //get closer to goal position
      if(pos < toPos) { pos += 1; } 
      if(pos > toPos) { pos -= 1; }
      //write the servo position
      if(invert) { SERVO.write(180-pos); }
      else { SERVO.write(pos); }
    } 
  }
}
int ServoMotor::getPos() { return pos; }
bool ServoMotor::isAttached() { return attached; }

// --- LASER RANGEFINDER --- //
Laser::Laser(int pin) { PIN = pin; }
void Laser::initialize() { pinMode(PIN,INPUT); }
int Laser::range(int mode) {
  int v = int(analogRead(PIN));
  switch(mode) {
	case 1: // Convert to Sharp Sensor 40-300mm
      return int(120.0 / (v * (5.0 / 1024.0)));
	case 2: // Convert to Sharp Sensor 100-800mm
	  return int(270.0 / (v * (5.0 / 1024.0)));
	case 3: // Convert to Sharp Sensor 200-1500mm
	  return int(650.0 / (v * (5.0 / 1024.0)));
	default: // No conversion, raw input 0-1023
	  return v;
	}
}

// --- VOLTMETER --- //
Voltmeter::Voltmeter(int pin, int led) { 
  PIN = pin; 
  LED = led; 
}
void Voltmeter::initialize() { 
  pinMode(PIN,INPUT); 
  pinMode(LED,OUTPUT); 
}
void Voltmeter::update() {
  //indicate that battery needs to be charged by turning RED led ON
  if(voltage() < 1190) { digitalWrite(LED,HIGH); } 
  else { digitalWrite(LED,LOW); }
}
int Voltmeter::voltage(int mode) { 
  int v = int(analogRead(PIN));
  switch(mode) {
	case 1: //convert 0-1023 analog in to 0-15 volts
      return int(v*1.7+23.0);
    default: // No conversion, raw input 0-1023
	  return v;
  }
}

// --- SERIAL HANDLER --- //
SerialHandler::SerialHandler(int inCnt, int outCnt) {
  //initialize input buffers  
  inNum = inCnt;
  inStr = "";
  for(int i = 0; i < 32; i++) { inData[i] = -1; }
  //initialize output buffers
  outNum = outCnt;
  outStr = "";
  for(int i = 0; i < 32; i++) { outData[i] = -1; }
}
void SerialHandler::initialize(int mode) {
  Serial.begin(57600);
  //Preformatted initial data for Megamark robot:
  if (mode == 0) {
	//Robot Actuators
	inData[0] = 0;  inData[1] = 0;  //leftWheel, rightWheel
	inData[2] = 90; inData[3] = 90; //leftShoulder, rightShoulder
	inData[4] = 90; inData[5] = 90; //leftElbow, rightElbow
	// L1,L2,L3,L4,L5,L6 grippers
	inData[6]=90; inData[7]=90; inData[8]=90; inData[9]=90; inData[10]=90; inData[11]=90;
	// R1,R2,R3,R4,R5,R6 grippers
	inData[12]=90; inData[13]=90; inData[14]=90; inData[15]=90; inData[16]=90; inData[17]=90;
    //Robot Sensors
	outData[0] = 0;  outData[1] = 0;  //leftLaser, rightLaser
  }
}
void SerialHandler::setData(int i, int val) { 
  if( 0 <= i && i < outNum ) { outData[i] = val; }
}
int SerialHandler::getData(int i) {
  if( 0 <= i && i < inNum ) { return inData[i]; }
}
void SerialHandler::read() { //Read incoming data ( formatted "{x,y,z}" )
  while(Serial.available()){
    //Get first char from buffer;
	chr = Serial.read();
    //begin parsing
    if(chr == '{') { inStr = ""; index = 0; }
    //extract number from data
    else if(chr == ',' || chr == '}') {
      inData[index] = inStr.toInt();
      index++; inStr = "";
      //Finished reading message
      if(chr == '}') { inStr = ""; index = 0; }   
    }
    //add char to current string
    else if (!isWhitespace(chr) && chr != '\n'){ inStr += chr; }
  }
}
void SerialHandler::write() { //Send outgoing data ( formatted "{x,y,z}" )
  outStr = "";
  if(outNum == 1) {
    outStr = "{ " + String(outData[0]) + " }\n";
  } else if (outNum > 1) {
    outStr = "{ ";
    for(int i= 0; i < outNum; i++) { 
      outStr += String(outData[i]); 
      if(i < outNum-1) { outStr += ", "; }
    }
    outStr += " }\n";
  } 
  Serial.print(outStr);
  Serial.flush();
}